# Introduction 简介

Later-joining players can also synchronize host upgrades now. 

后加入玩家现在也可以同步主机升级.

This mod only works if installed by the host.

此 MOD 需要主机安装才有效。