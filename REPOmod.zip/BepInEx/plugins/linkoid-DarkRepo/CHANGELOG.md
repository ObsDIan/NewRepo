* 1.2 - Fixed configs not loading on boot, and added descriptions.
* 1.1 - Added configs
* 1.0 - Release
