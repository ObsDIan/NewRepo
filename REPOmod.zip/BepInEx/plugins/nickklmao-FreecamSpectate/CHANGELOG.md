# v1.0.0 🔥
- Initial release

# v1.0.1
- Fixed poor grammar in the manifest 🥲

# v1.0.2
- Updated README (Forgot a keybind)
- Vertical movement now has last input priority