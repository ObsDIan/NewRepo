# Do you get bored spectating your friends?
This mod lets you fly around while spectating!

## Keybinds
**Z** - Toggles freecam (Can only be toggled while spectating)  
**W/A/S/D** - Moves forward, left, back, and right respectively  
**Jump/E** - Moves up  
**Crouch/Q** - Moves down  
**Shift** - Doubles movement speed  
**Middle Mouse** - Teleports your camera back to whoever you're spectating

## Note
When freecam is enabled, this mod disables the jump button's ability to cycle to the next player. Instead, you’ll need to use the designated keybinds, typically left click and right click.

