## 0.0.9
- New Repo on github is out
- New license is used for the mod
- New animation + sound effects fixes
- Glitches with spamming mute button fixed,
- Overall bug fixes and splitting Plugin.cs on github

## 0.0.8
- readme update

## 0.0.7
- removed unnecessary logging
- The Mute Button doesnt work when writing something in chat.

## 0.0.6
- fixed audio delay on mute button + other tweaks

## 0.0.5
- fixed an error that basicially was indeed doing serious damage + animation doesnt play twice when changing scenes

## 0.0.4
- remove a stupid debug log

## 0.0.3
- More Bugfixes, Sound Volume Settings in Config, Sound Effects, Better Animation, Saving state between scenes (Thanks for Hamunii for basicially helping me to do it, i would never do it on my own)
- jumping between version 0.0.2 / 0.0.3 will erase your config

## 0.0.2
- Updated precaching and new muted icon

## 0.0.1
- Initial release