## 0.1.2
### Fixed
- Modified code to ensure loading screens are no longer skipped

## 0.1.1
### Fixed
- Lobby unable to load due to the Steam Ticket Auth

## 0.1.0
### Initial release
- Players can now join your lobby whilst you're in a game
- Handling of spawning has been modified to only affect players that enter the lobby
- Variety of RPCs are no longer being buffered between scene changes