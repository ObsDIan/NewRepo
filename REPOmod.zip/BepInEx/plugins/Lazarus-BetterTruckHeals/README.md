**Fully configurable heal amount with REPOConfig!**

Increases Heal amount to 50 instead of default 25!