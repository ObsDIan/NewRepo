## v1.1.0 Update
- Now shows your vanilla selected color when opening the Select Color page
- Code now uses a publicized assembly instead of reflection

## v1.0.0 Release 😎
- Adds RGB color sliders to the Select Color page