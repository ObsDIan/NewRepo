# CustomColors

This mod adds RGB color sliders to the Select Color page.

Custom colors will sync to other players with the CustomColors mod installed. Vanilla players will see your last selected vanilla color.

![Example screenshot of the Select Color page](https://raw.githubusercontent.com/x753/REPO-CustomColors/refs/heads/main/example-screenshot.png)

## Credits
Programming by 753.

https://753.network/