# ⚠️ YOU MUST USE THE BEPINEX VERSION LISTED ON THE THUNDERSTORE PAGE [HERE](https://thunderstore.io/c/repo/p/BepInEx/BepInExPack/)!
# MorePlayers
Are you tired of not being able to change the max player count in R.E.P.O.? Well BOY do I have something for you!
- MorePlayers is a mod for R.E.P.O. that allows you to decrease or increase the max player cap.

# How do you change the max players cap?
Easy! Go to your installation folder for R.E.P.O. (Right click on R.E.P.O. on Steam -> Manage -> Browse local files), go to BepInEx -> config -> zelofi.MorePlayers.cfg, then adjust the "MaxPlayers" value!
> ❔ If you have a mod manager like Gale, you can change the .cfg settings in the launcher itself!

> ⚠️ In order for the .cfg file to appear, you must launch the game after installing the mod!

> ⚠️ If you manage to, setting the max player count to an insane number (Like 100 let's say) and filling the entire server with players WILL cause some issues, PUN is not exactly super stable when it comes to having a high number of players in a server.