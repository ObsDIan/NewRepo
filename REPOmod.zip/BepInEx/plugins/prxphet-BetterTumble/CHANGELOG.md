# 1.0.3
- Changed code for latest version of REPOConfig.
- Updated description.

# 1.0.2
- Fixed damage scale applying few times.

# 1.0.1
- REPOConfig support.
- Added a setting to scale the damage of tumble launch to enemies.

# 1.0.0
Initial release