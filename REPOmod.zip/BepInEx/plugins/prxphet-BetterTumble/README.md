# Description
**Ability to customize some player tumble launch settings. Using yourself as a weapon now should have more sense. Only host needs this mod to work (In theory).**

### Available settings:
* Disable self-damage when hitting an enemy.
* Scale the damage of tumble launch to enemies.

# Note
1. Find me (@prxphet) in R.E.P.O modding discord server and DM me if you have some bugs or problems with the mod.
2. Maybe I'll add some more settings in the future.