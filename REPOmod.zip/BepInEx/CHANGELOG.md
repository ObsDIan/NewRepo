# 1.0.3
- Add safeguards around missing Rigidbody

# 1.0.2
- Fix doors disconnecting from their hinge on movement
- Better future predictions
- Process network packets faster
- Fixed 60Hz jitter
- Added limits to config options

# 1.0.1
- Fix broken single player

# 1.0.0
- Initial release
